from musenet_midi_py.main import encode, decode
